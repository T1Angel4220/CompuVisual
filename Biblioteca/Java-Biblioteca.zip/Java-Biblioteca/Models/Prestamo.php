<?php
class Prestamo {
public static function obtenerTodos() {
    $db = Conexion::conectar();
    $stmt = $db->query("
        SELECT p.id, p.cedula_estudiante, p.fecha_prestamo, p.fecha_devolucion,
               e.nombre AS estudiante,
               l.id AS id_libro, l.titulo AS libro
        FROM prestamos p
        JOIN estudiantes e ON p.cedula_estudiante = e.cedula
        JOIN libros l ON p.id_libro = l.id
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


    public static function crear($data) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("INSERT INTO prestamos (cedula_estudiante, id_libro, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?, ?)");
        return $stmt->execute([
            $data['cedula_estudiante'],
            $data['id_libro'],
            $data['fecha_prestamo'],
            $data['fecha_devolucion']
        ]);
    }

    public static function eliminar($id) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("DELETE FROM prestamos WHERE id = ?");
        return $stmt->execute([$id]);
    }
public static function obtenerPorCedula($cedula) {
    $db = Conexion::conectar();
    $stmt = $db->prepare("
        SELECT p.id, p.cedula_estudiante, p.fecha_prestamo, p.fecha_devolucion,
               e.nombre AS estudiante,
               l.id AS id_libro, l.titulo AS libro
        FROM prestamos p
        JOIN estudiantes e ON p.cedula_estudiante = e.cedula
        JOIN libros l ON p.id_libro = l.id
        WHERE p.cedula_estudiante = ?
    ");
    $stmt->execute([$cedula]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

    
}
?>
