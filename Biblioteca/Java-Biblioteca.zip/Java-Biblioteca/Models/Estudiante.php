<?php
class Estudiante {
    public static function obtenerTodos() {
        $db = Conexion::conectar();
        $stmt = $db->query("SELECT * FROM estudiantes");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function crear($data) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("INSERT INTO estudiantes (cedula, nombre, apellido, direccion, telefono) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$data['cedula'], $data['nombre'], $data['apellido'], $data['direccion'], $data['telefono']]);
    }

    public static function actualizar($data) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("UPDATE estudiantes SET nombre = ?, apellido = ?, direccion = ?, telefono = ? WHERE cedula = ?");
        return $stmt->execute([$data['nombre'], $data['apellido'], $data['direccion'], $data['telefono'], $data['cedula']]);
    }

    public static function eliminar($cedula) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("DELETE FROM estudiantes WHERE cedula = ?");
        return $stmt->execute([$cedula]);
    }
}
?>
