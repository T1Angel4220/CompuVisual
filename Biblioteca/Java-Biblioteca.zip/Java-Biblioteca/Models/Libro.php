<?php
class Libro {
    public static function obtenerTodos() {
        $db = Conexion::conectar();
        $stmt = $db->query("SELECT * FROM libros");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function crear($data) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("INSERT INTO libros (titulo, autor, anio) VALUES (?, ?, ?)");
        return $stmt->execute([$data['titulo'], $data['autor'], $data['anio']]);
    }

    public static function actualizar($data) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("UPDATE libros SET titulo = ?, autor = ?, anio = ? WHERE id = ?");
        return $stmt->execute([$data['titulo'], $data['autor'], $data['anio'], $data['id']]);
    }

    public static function eliminar($id) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("DELETE FROM libros WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>
