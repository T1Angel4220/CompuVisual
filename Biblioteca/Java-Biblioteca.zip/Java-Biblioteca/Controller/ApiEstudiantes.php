<?php
require_once '../models/Estudiante.php';
require_once '../models/conexion.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");


if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
case 'GET':
    $result = Estudiante::obtenerTodos();

    // Validación adicional
    if (!is_array($result)) {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Error al obtener estudiantes"
        ]);
        exit;
    }

    echo json_encode($result);
    break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode(Estudiante::crear($data));
        break;
    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode(Estudiante::actualizar($data));
        break;
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $cedula = $query['cedula'] ?? null;
        echo json_encode(Estudiante::eliminar($cedula));
        break;
}
?>
