// ==================== ESTUDIANTES ====================
const API_BASE = 'http://localhost/Java-Biblioteca/controller/ApiEstudiantes.php';
const API_LIBROS = 'http://localhost/Java-Biblioteca/controller/ApiLibros.php';
const API_PRESTAMOS = 'http://localhost/Java-Biblioteca/controller/ApiPrestamos.php';

let selectedRow = null;
let selectedLibro = null;
let selectedPrestamo = null;

$(document).ready(() => {
    loadData();
    cargarLibros();
    cargarPrestamos();
});

// ---------- ESTUDIANTES ----------
function loadData() {
    $.ajax({
        url: API_BASE,
        type: "GET",
        dataType: "json",
        success: function (data) {
            const tbody = $('#tablaEstudiantes').empty();
            data.forEach(est => {
                const row = $('<tr></tr>').click(() => selectRow(row, est));
                row.append(`<td>${est.cedula}</td>`);
                row.append(`<td>${est.nombre}</td>`);
                row.append(`<td>${est.apellido}</td>`);
                row.append(`<td>${est.direccion}</td>`);
                row.append(`<td>${est.telefono}</td>`);
                tbody.append(row);
            });
        },
        error: function (xhr) {
            alert('Error al cargar estudiantes: ' + xhr.responseText);
        }
    });
}

function selectRow(rowElement, rowData) {
    $('#tablaEstudiantes tr').removeClass('table-active');
    $(rowElement).addClass('table-active');
    selectedRow = rowData;
}

function newUser() {
    $('#fm')[0].reset();
    selectedRow = null;
    $('[name="cedula"]').prop('disabled', false);
    url = API_BASE;
    $('#modalTitle').text('Nuevo Estudiante');
    new bootstrap.Modal(document.getElementById('userModal')).show();
}

function editUser() {
    if (!selectedRow) return alert('Primero seleccione un estudiante');
    $('#fm')[0].reset();
    for (let key in selectedRow) {
        $(`[name="${key}"]`).val(selectedRow[key]);
    }
    $('[name="cedula"]').prop('disabled', true);
    url = `${API_BASE}?cedula=${selectedRow.cedula}`;
    $('#modalTitle').text('Editar Estudiante');
    new bootstrap.Modal(document.getElementById('userModal')).show();
}

function saveUser() {
    const formData = $('#fm').serializeArray();
    const dataObj = {};
    formData.forEach(item => dataObj[item.name] = item.value);
    if (url.includes('cedula=')) dataObj.cedula = selectedRow.cedula;
    const method = url.includes('cedula=') ? 'PUT' : 'POST';

    $.ajax({
        url: url,
        type: method,
        data: JSON.stringify(dataObj),
        contentType: 'application/json',
        success: function () {
            bootstrap.Modal.getInstance(document.getElementById('userModal')).hide();
            loadData();
            alert('Estudiante guardado correctamente');
        },
        error: function (xhr) {
            alert('Error al guardar: ' + xhr.responseText);
        }
    });
}

function proxyDestroyUser() {
    if (!selectedRow) return alert('Selecciona un estudiante');
    if (confirm(`¿Eliminar a ${selectedRow.nombre} ${selectedRow.apellido}?`)) {
        destroyUser(selectedRow.cedula);
    }
}

function destroyUser(cedula) {
    $.ajax({
        url: `${API_BASE}?cedula=${encodeURIComponent(cedula)}`,
        type: 'DELETE',
        success: function () {
            loadData();
            alert('Estudiante eliminado');
        },
        error: function (xhr) {
            alert('Error al eliminar: ' + xhr.responseText);
        }
    });
}

// ---------- LIBROS ----------
function cargarLibros() {
    $.get(API_LIBROS, data => {
        const tbody = $('#tablaLibros').empty();
        data.forEach(lib => {
            const row = $('<tr></tr>').click(() => selectLibro(row, lib));
            row.append(`<td>${lib.id}</td>`);
            row.append(`<td>${lib.titulo}</td>`);
            row.append(`<td>${lib.autor}</td>`);
            row.append(`<td>${lib.anio}</td>`);
            tbody.append(row);
        });
    });
}

function selectLibro(rowElement, rowData) {
    $('#tablaLibros tr').removeClass('table-active');
    $(rowElement).addClass('table-active');
    selectedLibro = rowData;
}

function nuevoLibro() {
    const titulo = prompt("Título:");
    const autor = prompt("Autor:");
    const anio = prompt("Año:");
    if (!titulo || !autor || !anio) return;

    $.ajax({
        url: API_LIBROS,
        type: 'POST',
        data: JSON.stringify({ titulo, autor, anio }),
        contentType: 'application/json',
        success: cargarLibros
    });
}

function editarLibro() {
    if (!selectedLibro) return alert("Selecciona un libro");

    const titulo = prompt("Título:", selectedLibro.titulo);
    const autor = prompt("Autor:", selectedLibro.autor);
    const anio = prompt("Año:", selectedLibro.anio);

    $.ajax({
        url: API_LIBROS,
        type: 'PUT',
        data: JSON.stringify({ id: selectedLibro.id, titulo, autor, anio }),
        contentType: 'application/json',
        success: cargarLibros
    });
}function buscarPrestamosPorCedula() {
    const cedula = $('#buscarCedula').val().trim();
    if (!cedula) return alert("Ingrese una cédula");

    $.ajax({
        url: `${API_PRESTAMOS}?cedula=${encodeURIComponent(cedula)}`,
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            const tbody = $('#tablaPrestamos').empty();
            if (Array.isArray(data) && data.length > 0) {
                data.forEach(pre => {
                    const row = $('<tr></tr>').click(() => selectPrestamo(row, pre));
                    row.append(`<td>${pre.id}</td>`);
                    row.append(`<td>${pre.cedula_estudiante}</td>`);
                    row.append(`<td>${pre.estudiante}</td>`);
                    row.append(`<td>${pre.libro}</td>`);
                    row.append(`<td>${pre.fecha_prestamo}</td>`);
                    row.append(`<td>${pre.fecha_devolucion || ''}</td>`);
                    tbody.append(row);
                });
            } else {
                alert("No se encontraron préstamos para esa cédula.");
            }
        },
        error: function (xhr) {
            alert("Error al buscar préstamos: " + xhr.responseText);
        }
    });
}


function eliminarLibro() {
    if (!selectedLibro) return alert("Selecciona un libro");

    if (confirm(`¿Eliminar el libro "${selectedLibro.titulo}"?`)) {
        $.ajax({
            url: API_LIBROS + '?id=' + selectedLibro.id,
            type: 'DELETE',
            success: cargarLibros
        });
    }
}

// ---------- PRESTAMOS ----------
function cargarPrestamos() {
    $.get(API_PRESTAMOS, data => {
        const tbody = $('#tablaPrestamos').empty();
        data.forEach(pre => {
            const row = $('<tr></tr>').click(() => selectPrestamo(row, pre));
            row.append(`<td>${pre.id}</td>`);
            row.append(`<td>${pre.cedula_estudiante}</td>`);
            row.append(`<td>${pre.estudiante}</td>`);
            row.append(`<td>${pre.libro}</td>`);
            row.append(`<td>${pre.fecha_prestamo}</td>`);
            row.append(`<td>${pre.fecha_devolucion || ''}</td>`);
            tbody.append(row);
        });
    });
}

function selectPrestamo(rowElement, rowData) {
    $('#tablaPrestamos tr').removeClass('table-active');
    $(rowElement).addClass('table-active');
    selectedPrestamo = rowData;
}

function nuevoPrestamo() {
    const cedula_estudiante = prompt("Cédula del estudiante:");
    const id_libro = prompt("ID del libro:");
    const fecha_prestamo = prompt("Fecha préstamo (YYYY-MM-DD):", new Date().toISOString().slice(0, 10));
    const fecha_devolucion = prompt("Fecha devolución (YYYY-MM-DD):");

    $.ajax({
        url: API_PRESTAMOS,
        type: 'POST',
        data: JSON.stringify({ cedula_estudiante, id_libro, fecha_prestamo, fecha_devolucion }),
        contentType: 'application/json',
        success: cargarPrestamos
    });
}

function eliminarPrestamo() {
    if (!selectedPrestamo) return alert("Selecciona un préstamo");

    if (confirm(`¿Eliminar préstamo ID ${selectedPrestamo.id}?`)) {
        $.ajax({
            url: API_PRESTAMOS + '?id=' + selectedPrestamo.id,
            type: 'DELETE',
            success: cargarPrestamos
        });
    }
}
// ======================= MODALES LIBRO =========================
function nuevoLibro() {
    $('#fmLibro')[0].reset();
    $('#libro-id').val('');
    new bootstrap.Modal(document.getElementById('libroModal')).show();
}

function editarLibro() {
    if (!selectedLibro) return alert("Selecciona un libro");
    $('#libro-id').val(selectedLibro.id);
    $('[name="titulo"]').val(selectedLibro.titulo);
    $('[name="autor"]').val(selectedLibro.autor);
    $('[name="anio"]').val(selectedLibro.anio);
    new bootstrap.Modal(document.getElementById('libroModal')).show();
}

function guardarLibro() {
    const libro = {
        id: $('#libro-id').val(),
        titulo: $('[name="titulo"]').val(),
        autor: $('[name="autor"]').val(),
        anio: $('[name="anio"]').val()
    };

    const method = libro.id ? 'PUT' : 'POST';
    $.ajax({
        url: API_LIBROS,
        type: method,
        data: JSON.stringify(libro),
        contentType: 'application/json',
        success: () => {
            bootstrap.Modal.getInstance(document.getElementById('libroModal')).hide();
            cargarLibros();
        }
    });
}

// ======================= MODALES PRÉSTAMO =========================
function nuevoPrestamo() {
    $('#fmPrestamo')[0].reset();
    cargarOpcionesPrestamo();
    new bootstrap.Modal(document.getElementById('prestamoModal')).show();
}

function cargarOpcionesPrestamo() {
    // cargar estudiantes
    $.get(API_BASE, data => {
        console.log("Respuesta estudiantes:", data);  // <-- VER en consola
        const select = $('#selectEstudiantes').empty().append('<option value="">Seleccione</option>');
        try {
            const parsed = typeof data === "string" ? JSON.parse(data) : data;
            if (!Array.isArray(parsed)) throw "No es un array";

            const select = $('#selectEstudiantes').empty().append('<option value="">Seleccione</option>');
            parsed.forEach(est => {
                select.append(`<option value="${est.cedula}">${est.cedula} - ${est.nombre} ${est.apellido}</option>`);
            });
        } catch (e) {
            alert("Error cargando estudiantes. No se recibió un array válido.");
            console.error("Error parseando estudiantes:", data, e);
        }


        data.forEach(est => {
            select.append(`<option value="${est.cedula}">${est.nombre} ${est.apellido}</option>`);
        });
    });


    // cargar libros disponibles (no prestados)
    $.get(API_LIBROS, libros => {
        $.get(API_PRESTAMOS, prestamos => {
            const librosPrestados = prestamos.map(p => p.id_libro?.toString());
            const select = $('#selectLibros').empty().append('<option value="">Seleccione</option>');
            libros.forEach(lib => {
                if (!librosPrestados.includes(lib.id.toString())) {
                    select.append(`<option value="${lib.id}">${lib.titulo} - ${lib.autor}</option>`);
                }
            });
        });
    });
}

function guardarPrestamo() {
    const form = $('#fmPrestamo');
    const data = {
        cedula_estudiante: form.find('[name="cedula_estudiante"]').val(),
        id_libro: form.find('[name="id_libro"]').val(),
        fecha_prestamo: form.find('[name="fecha_prestamo"]').val(),
        fecha_devolucion: form.find('[name="fecha_devolucion"]').val()
    };

    if (!data.cedula_estudiante || !data.id_libro || !data.fecha_prestamo) {
        alert("Todos los campos obligatorios deben estar llenos.");
        return;
    }

    $.ajax({
        url: API_PRESTAMOS,
        type: 'POST',
        data: JSON.stringify(data),
        contentType: 'application/json',
        success: () => {
            bootstrap.Modal.getInstance(document.getElementById('prestamoModal')).hide();
            cargarPrestamos();
        },
        error: function (xhr) {
            alert("Error al guardar préstamo: " + xhr.responseText);
        }
    });
}


