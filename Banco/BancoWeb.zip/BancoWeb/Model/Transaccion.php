<?php
require_once __DIR__ . '/conexion.php';
class Transaccion {
public static function registrar($cedula, $tipo, $monto) {
    $db = Conexion::conectar();

    // Obtener ID del cliente por cédula
    $stmtCliente = $db->prepare("SELECT id FROM clientes WHERE cedula = ?");
    $stmtCliente->execute([$cedula]);
    $cliente = $stmtCliente->fetch(PDO::FETCH_ASSOC);
    
    if (!$cliente) {
        return false;
    }

    $stmt = $db->prepare("INSERT INTO transacciones (cliente_id, tipo, monto) VALUES (?, ?, ?)");
    return $stmt->execute([$cliente['id'], $tipo, $monto]);
}


public static function obtenerPorCedula($cedula) {
    $db = Conexion::conectar();
    $stmt = $db->prepare("
        SELECT t.tipo, t.monto, t.fecha, c.nombre AS cliente, c.cedula
        FROM transacciones AS t
        INNER JOIN clientes AS c ON c.id = t.cliente_id
        WHERE c.cedula = ?
        ORDER BY t.fecha DESC
    ");
    $stmt->execute([$cedula]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

public static function obtenerTodas() {
    $db = Conexion::conectar();
    $stmt = $db->query("
        SELECT t.tipo, t.monto, t.fecha, c.nombre AS cliente, c.cedula
        FROM transacciones AS t
        INNER JOIN clientes AS c ON c.id = t.cliente_id
        ORDER BY t.fecha DESC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}



}
?>
