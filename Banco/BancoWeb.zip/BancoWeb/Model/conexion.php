<?php
class Conexion {
    public static function conectar() {
        return new PDO("mysql:host=localhost;dbname=banco", "root", "Angel_4220");
    }
}
?>
