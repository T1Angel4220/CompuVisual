<?php

require_once __DIR__ . '/conexion.php';
class Cliente {
    public static function obtenerTodos() {
        $db = Conexion::conectar();
        $stmt = $db->query("SELECT * FROM clientes");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function crear($data) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("INSERT INTO clientes (nombre, cedula) VALUES (?, ?)");
        return $stmt->execute([$data['nombre'], $data['cedula']]);
    }

    public static function obtenerPorCedula($cedula) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("SELECT * FROM clientes WHERE cedula = ?");
        $stmt->execute([$cedula]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function actualizarSaldo($cedula, $nuevoSaldo) {
        $db = Conexion::conectar();
        $stmt = $db->prepare("UPDATE clientes SET saldo = ? WHERE cedula = ?");
        return $stmt->execute([$nuevoSaldo, $cedula]);
    }
}
?>
