<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
require_once('../model/Cliente.php');
require_once('../model/Transaccion.php');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['cedula'])) {
            echo json_encode(Cliente::obtenerPorCedula($_GET['cedula']));
        } else {
            echo json_encode(Cliente::obtenerTodos());
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (isset($data['accion'])) {
            $cliente = Cliente::obtenerPorCedula($data['cedula']);
            if (!$cliente) {
                echo json_encode(['error' => 'Cliente no encontrado']);
                exit;
            }

            $saldoActual = $cliente['saldo'];
            $monto = floatval($data['monto']);

            if ($data['accion'] === 'deposito') {
                $nuevoSaldo = $saldoActual + $monto;
                Cliente::actualizarSaldo($data['cedula'], $nuevoSaldo);
                Transaccion::registrar($data['cedula'], 'deposito', $monto);
                echo json_encode(['success' => true, 'saldo' => $nuevoSaldo]);

            } elseif ($data['accion'] === 'retiro') {
                if ($monto > $saldoActual) {
                    echo json_encode(['error' => 'Saldo insuficiente']);
                    exit;
                }
                $nuevoSaldo = $saldoActual - $monto;
                Cliente::actualizarSaldo($data['cedula'], $nuevoSaldo);
                Transaccion::registrar($data['cedula'], 'retiro', $monto);
                echo json_encode(['success' => true, 'saldo' => $nuevoSaldo]);
            }
        } else {
            Cliente::crear($data);
            echo json_encode(['success' => true]);
        }
        break;

    default:
        echo json_encode(['error' => 'Método no soportado']);
        break;
}
?>
