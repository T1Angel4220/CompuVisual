const API_BANCO = 'http://localhost/bancoWeb/controller/ApiBanco.php';
const API_TRANS = 'http://localhost/bancoWeb/controller/ApiTransacciones.php';

$(document).ready(() => {
    cargarClientes();

    $("#formCliente").submit(e => {
        e.preventDefault();
        const cliente = {
            nombre: $("#nombre").val(),
            cedula: $("#cedula").val()
        };
        $.ajax({
            url: API_BANCO,
            type: "POST",
            data: JSON.stringify(cliente),
            success: () => {
                alert("Cliente guardado");
                $("#formCliente")[0].reset();
                cargarClientes(); // Recargar clientes después de guardar
            }
        });
    });
});

function cargarClientes() {
    $.get(API_BANCO, data => {
        const select = $("#oper-cedula").empty();
        select.append('<option value="">Seleccione un cliente</option>');
        data.forEach(cliente => {
            select.append(`<option value="${cliente.cedula}">${cliente.nombre} (${cliente.cedula})</option>`);
        });
    });
}

function realizarOperacion(tipo) {
    const cedula = $("#oper-cedula").val();
    const monto = parseFloat($("#monto").val());
    if (!cedula || isNaN(monto)) {
        alert("Cédula y monto válidos requeridos");
        return;
    }

    $.ajax({
        url: API_BANCO,
        type: "POST",
        data: JSON.stringify({ cedula, monto, accion: tipo }),
        success: res => {
            if (res.success) {
                alert(`Operación exitosa. Nuevo saldo: $${res.saldo}`);
                consultarTransacciones();
            } else {
                alert(res.error);
            }
        }
    });
}

function consultarTransacciones() {
    const cedula = $("#oper-cedula").val();
    if (!cedula) return alert("Seleccione un cliente");

    $.get(`${API_TRANS}?cedula=${cedula}`, res => {
        const tbody = $("#trans-table").empty();
        res.forEach(t => {
            tbody.append(`
                <tr>
                    <td>${t.tipo}</td>
                    <td>$${t.monto}</td>
                    <td>${t.fecha}</td>
                </tr>
            `);
        });
    });
}
function consultarTransacciones() {
    $.get(API_TRANS, res => {
        const tbody = $("#trans-table").empty();
        if (res.length === 0) {
            tbody.append('<tr><td colspan="4">Sin transacciones registradas</td></tr>');
            return;
        }

        res.forEach(t => {
            tbody.append(`
                <tr>
                    <td>${t.tipo}</td>
                    <td>$${t.monto}</td>
                    <td>${t.fecha}</td>
                    <td>${t.cliente} (${t.cedula})</td>
                </tr>
            `);
        });
    }).fail(err => {
        console.error("Error en petición transacciones:", err);
    });
}
function buscarPorCedula() {
    const cedula = $("#buscar-cedula").val().trim();
    if (!cedula) {
        alert("Ingrese una cédula");
        return;
    }

    $.get(`${API_TRANS}?cedula=${cedula}`, res => {
        const tbody = $("#trans-table").empty();
        if (res.length === 0) {
            tbody.append('<tr><td colspan="4">No se encontraron transacciones para esa cédula</td></tr>');
            return;
        }

        res.forEach(t => {
            tbody.append(`
                <tr>
                    <td>${t.tipo}</td>
                    <td>$${t.monto}</td>
                    <td>${t.fecha}</td>
                    <td>${t.cliente} (${t.cedula})</td>
                </tr>
            `);
        });
    }).fail(err => {
        console.error("Error en búsqueda por cédula:", err);
    });
}


