<?php
header('Content-Type: application/json; charset=utf-8');
include_once '../Models/Insert.php';
include_once '../Models/Select.php';
include_once '../Models/Delete.php';
include_once '../Models/Update.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$opc = $_SERVER['REQUEST_METHOD'];

switch ($opc) {
    case 'POST':
        crudInsert::Insertar();
        break;
    case 'GET':
        crudSelect::selecionarEstudiante();
        break;
    case 'PUT':
        $inputData = file_get_contents("php://input");
        $putData = json_decode($inputData, true);

        $cedula = $putData['cedula'] ?? null;
        $nombre = $putData['nombre'] ?? null;
        $apellido = $putData['apellido'] ?? null;
        $direccion = $putData['direccion'] ?? null;
        $telefono = $putData['telefono'] ?? null;

        CrudActualizar::actualizarEstudiante($cedula, $nombre, $apellido, $direccion, $telefono);
        break;

    case 'DELETE':
        $cedula = $_GET['cedula'] ?? null;
        if ($cedula) {
            $resultado = crudEliminar::eliminarEstudiante($cedula);
            echo json_encode($resultado);
        } else {
            echo json_encode(["success" => false, "error" => "No se proporcionó una cédula para eliminar."]);
        }
        break;
}
?>