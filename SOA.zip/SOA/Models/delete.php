<?php
class crudEliminar
{
    public static function eliminarEstudiante($cedula)
    {
        include_once("conexion.php");

        $objeto = new conexion();
        $conexion = $objeto->conectar();
        $sqlDelete = "DELETE FROM ESTUDIANTES WHERE cedula = $cedula";
        $resultado = $conexion->prepare($sqlDelete);
        $ok = $resultado->execute();

        if ($ok) {
            return ["success" => true, "message" => "Se eliminó el estudiante"];
        } else {
            return ["success" => false, "error" => "No se pudo eliminar"];
        }
    }
}
