<?php
include_once 'Conexion.php';
class crudInsert
{

    public static function Insertar()
    {
        $object = new conexion();
        $con = $object->conectar();

        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, true);

        $cedula = $input['cedula'] ?? null;
        $nombre = $input['nombre'] ?? null;
        $apellido = $input['apellido'] ?? null;
        $direccion = $input['direccion'] ?? null;
        $telefono = $input['telefono'] ?? null;

        if ($cedula && $nombre && $apellido && $direccion && $telefono) {
            try {
                $SqlInsert = "INSERT INTO estudiantes VALUES(?, ?, ?, ?, ?)";
                $result = $con->prepare($SqlInsert);
                $result->execute([$cedula, $nombre, $apellido, $direccion, $telefono]);

                echo json_encode(["success" => true, "message" => "Se guardó correctamente el registro"]);
            } catch (PDOException $e) {
                echo json_encode(["success" => false, "error" => $e->getMessage()]);
            }
        } else {
            echo json_encode(["success" => false, "error" => "Datos insuficientes"]);
        }
    }
}
?>