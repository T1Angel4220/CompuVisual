<?php
include_once "conexion.php";

class crudSelect
{
    public static function selecionarEstudiante()
    {
        $objeto = new conexion();
        $conexion = $objeto->conectar();
        $sqlSelect = "SELECT * FROM estudiantes";
        $result = $conexion->prepare($sqlSelect);
        $result->execute();
        $data = $result->fetchAll(PDO::FETCH_ASSOC);
        $dataJS = json_encode($data);
        print_r($dataJS);
    }
}
?>