<?php
include_once 'Conexion.php';

class CrudActualizar
{
    public static function actualizarEstudiante($cedula, $nombre, $apellido, $direccion, $telefono)
    {
        $object = new Conexion();
        $con = $object->conectar();

        // Verificar si el estudiante con la cédula existe
        $sqlCheck = "SELECT * FROM estudiantes WHERE cedula = ?";
        $checkResult = $con->prepare($sqlCheck);
        $checkResult->execute([$cedula]);

        if ($checkResult->rowCount() == 0) {
            // Si no se encuentra el estudiante
            echo json_encode(["success" => false, "error" => "Estudiante no encontrado."]);
            return;
        }

        // Si el estudiante existe, entonces procedemos a la actualización
        $sqlUpdate = "UPDATE estudiantes SET nombre = ?, apellido = ?, direccion = ?, telefono = ? WHERE cedula = ?";
        $result = $con->prepare($sqlUpdate);
        $result->execute([$nombre, $apellido, $direccion, $telefono, $cedula]);

        // Verificar si los datos han cambiado
        if ($result->rowCount() > 0) {
            echo json_encode(["success" => true, "message" => "Estudiante actualizado correctamente."]);
        } else {
            echo json_encode(["success" => false, "error" => "No se realizaron cambios. Los datos ya son los mismos."]);
        }
    }
}
?>
