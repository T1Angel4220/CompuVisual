<?php
// Array asociativos
// JSON encode; Convierte un php a un string JSON
// JSON decode; Convierte un String JSON a un php

$arrayasociativo = array("nombre" => "Cristian", "apellido" => "Amaya", "edad" => 45);
print_r($arrayasociativo);
echo "<br>";
print_r(gettype($arrayasociativo));
echo "<br>";
$mijsonarray = json_encode($arrayasociativo);
echo ($mijsonarray);
echo "<br>";
echo (gettype($mijsonarray));
echo "<br>";
echo "<br>";
$mijsonPHP = json_decode($mijsonarray);
print_r($mijsonPHP);
echo "<br>";
print_r(gettype($mijsonPHP));
echo "<br>";
echo "<br>";
echo "<br>";

$array = array("Nicolas", "Mateo", "Sebastian");
print_r($array);
echo "<br>";
print_r(gettype($array));
echo "<br>";
$jsonarray = json_encode($array);
echo ($jsonarray);
echo "<br>";
echo (gettype($jsonarray));
echo "<br>";
$phparrat = json_decode($jsonarray);
print_r($phparrat);
echo "<br>";
print_r(gettype($phparrat));
echo "<br>";
echo "<br>";
echo "<br>";

$objeto = new stdClass();
$objeto->Nombre = "Mateo";
$objeto->Apellido = "Zorrilla";
print_r($objeto);
echo "<br>";
print_r(value: gettype($objeto));
echo "<br>";
$objetoJSON = json_encode($objeto);
echo ($objetoJSON);
echo "<br>";
echo (gettype($objetoJSON));
echo "<br>";
$phpobjeto = json_decode($objetoJSON);
print_r($phpobjeto);
echo "<br>";
print_r(gettype($phpobjeto));
echo "<br>";
echo "<br>";
echo "<br>";

$estudiante = '[
    {
        "nombre": "Cristian",
        "apellido": "Amaya",
        "Edad": 22,
        "Educacion": [
            {
                "Primaria": "UE 17 de Abril",
                "colegio": "Bolivar",
                "Universidad": "UTA"
            }
        ]
    },
    {
        "nombre": "Nicolas",
        "apellido": "Arcos",
        "Edad": 21,
        "Educacion": [
            {
                "Primaria": "La Salle",
                "colegio": "Bolivar",
                "Universidad": "UTA"
            }
        ]
    }
]';

/*
echo ($estudiante);
echo "<br>";
echo (gettype($estudiante));
echo "<br>";
echo "<br>";
*/
$estudiantePHP = json_decode($estudiante);
print_r($estudiantePHP);
echo "<br>";
print_r(gettype($estudiantePHP));
echo "<br>";
echo "<br>";

for ($i = 0; $i < count($estudiantePHP); $i++) {
    echo ($estudiantePHP[$i]->nombre . " ");
}
;

?>