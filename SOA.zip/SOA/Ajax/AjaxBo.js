
//bootstrap actualizar tabla
function actualizarTabla() {
    $.ajax({
        url: '../Controller/ApiRest.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            let tbody = $("#tabla-body");
            tbody.empty();

            data.forEach(function (item) {
                let row = `
                    <tr>
                        <td>${item.cedula}</td>
                        <td>${item.nombre}</td>
                        <td>${item.apellido}</td>
                        <td>${item.direccion}</td>
                        <td>${item.telefono}</td>
                        <td>
                            <a href="#" class="edit" title="Editar" data-toggle="tooltip" onclick="abrirModalEditar('${item.cedula}', '${item.nombre}', '${item.apellido}', '${item.direccion}', '${item.telefono}')">
                                <i class="material-icons">&#xE254;</i>
                            </a>
                            <a href="#" class="delete" title="Eliminar" data-toggle="tooltip" onclick="eliminarDatos('${item.cedula}')">
                                <i class="material-icons">&#xE872;</i>
                            </a>
                        </td>
                    </tr>
                `;
                tbody.append(row);
            });

            $('[data-toggle="tooltip"]').tooltip();
        },
        error: function (xhr, status, error) {
            console.error("Error al cargar datos:", error);
        }
    });
}
//bootstrap eliminar
function eliminarDatos(cedula) {

    $.ajax({
        url: "../Controller/ApiRest.php?cedula=" + encodeURIComponent(cedula),
        type: "DELETE",
        dataType: "json",
        success: function (response) {
            if (response.message) {
                actualizarTabla(); 
            } else {
                alert("Error al eliminar: " + (response.error || "Error desconocido"));
            }
        },
        error: function (xhr, status, error) {
            console.error("Error al eliminar:", error);
        }
    });
}

$(document).ready(function () {
    actualizarTabla();
});













function abrirModalEditar(cedula, nombre, apellido, direccion, telefono) {
    $("#cedulaEditar").val(cedula);
    $("#nombreEditar").val(nombre);
    $("#apellidoEditar").val(apellido);
    $("#direccionEditar").val(direccion);
    $("#telefonoEditar").val(telefono);

    $("#modalEditar").modal('show');
}



