$(document).ready(function () {
    // Esta parte vieja ya no sirve
    
    $.ajax({
        url: '../Controller/ApiRest.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            $('#dg').datagrid('loadData', data);
            $('#dg').datagrid('reload');
        }
    });
    
//bootstrap cargar datos
    $.ajax({
        url: '../Controller/ApiRest.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            let tbody = $("#tabla-body"); 
            tbody.empty(); 

// dentro de la función actualizarTabla()
data.forEach(function (item) {
    let row = `
        <tr>
            <td>${item.cedula}</td>
            <td>${item.nombre}</td>
            <td>${item.apellido}</td>
            <td>${item.direccion}</td>
            <td>${item.telefono}</td>
            <td>
                <a href="#" class="edit" title="Editar" data-toggle="tooltip"
                   onclick="abrirModalEditar('${item.cedula}', '${item.nombre}', '${item.apellido}', '${item.direccion}', '${item.telefono}')">
                    <i class="material-icons">&#xE254;</i>
                </a>
                <a href="#" class="delete" title="Eliminar" data-toggle="tooltip" onclick="eliminarDatos('${item.cedula}')">
                    <i class="material-icons">&#xE872;</i>
                </a>
            </td>
        </tr>
    `;
    tbody.append(row);
});


            $('[data-toggle="tooltip"]').tooltip(); // Reactivamos tooltips
        },
        error: function (xhr, status, error) {
            console.error(error);
        }
    });
});

//bootstrap eliminar
function eliminarDatos(cedula) {

    $.ajax({
        url: "../Controller/ApiRest.php?cedula=" + encodeURIComponent(cedula),
        type: "DELETE",
        dataType: "json",
        success: function (response) {
            if (response.message) {
                actualizarTabla(); // Aquí automáticamente se actualiza
            } else {
                alert("Error al eliminar: " + (response.error || "Error desconocido"));
            }
        },
        error: function (xhr, status, error) {
            console.error("Error al eliminar:", error);
        }
    });
}

// Cargar los datos iniciales automáticamente cuando el documento esté listo
$(document).ready(function () {
    actualizarTabla();
});

//bootstrap actualizar tabla
function actualizarTabla() {
    $.ajax({
        url: '../Controller/ApiRest.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            let tbody = $("#tabla-body");
            tbody.empty();

            data.forEach(function (item) {
                let row = `
                    <tr>
                        <td>${item.cedula}</td>
                        <td>${item.nombre}</td>
                        <td>${item.apellido}</td>
                        <td>${item.direccion}</td>
                        <td>${item.telefono}</td>
                        <td>
                            <a href="#" class="edit" title="Editar" data-toggle="tooltip">
                                <i class="material-icons">&#xE254;</i>
                            </a>
                            <a href="#" class="delete" title="Eliminar" data-toggle="tooltip" onclick="eliminarDatos('${item.cedula}')">
                                <i class="material-icons">&#xE872;</i>
                            </a>
                        </td>
                    </tr>
                `;
                tbody.append(row);
            });

            $('[data-toggle="tooltip"]').tooltip();
        },
        error: function (xhr, status, error) {
            console.error("Error al cargar datos:", error);
        }
    });
}



function guardarDatos() {
    var formData = {
        cedula: $('input[name="cedula"]').val(),
        nombre: $('input[name="nombre"]').val(),
        apellido: $('input[name="apellido"]').val(),
        direccion: $('input[name="direccion"]').val(),
        telefono: $('input[name="telefono"]').val()
    };

    $.ajax({
        url: "../Controller/ApiRest.php",
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(formData),
        success: function (response) {
            if (response.success) {
                actualizarTabla();
            } else {
                alert("Error al guardar: " + response.error);
            }
        }
    });
}

function eliminarDatos(cedula) {
    $.ajax({
        url: "../Controller/ApiRest.php?cedula=" + encodeURIComponent(cedula),
        type: "DELETE",
        dataType: "json",
        success: function (response) {
            if (response.message) {
                actualizarTabla();
            } else {
                alert("Error al eliminar: " + (response.error || "Desconocido"));
            }
        }
    });
}

function actualizarDatosDayle(cedula) {
    const formData = {
        cedula: $('input[name="cedula"]').val(),
        nombre: $('input[name="nombre"]').val(),
        apellido: $('input[name="apellido"]').val(),
        direccion: $('input[name="direccion"]').val(),
        telefono: $('input[name="telefono"]').val()
    };
    $.ajax({
        url: "../Controller/ApiRest.php",
        method: "CRISTIAN",
        contentType: "application/json",
        data: JSON.stringify(formData),
        success: function (response) {
            actualizarTabla();
            $("#fm")[0].reset();
            $("#dlg").dialog("close");
        },
        error: function () {
            $.message.alert("Error", "Hubo un probkema al actualizar el usuario.");
        }
    });
}

function destroyUser2() {
    var row = $('#dg').datagrid('getSelected');
    if (row) {
        $.messager.confirm('Confirm', 'Are you sure you want to destroy this user?', function (r) {
            if (r) {
                $.ajax({
                    url: "../Controller/ApiRest.php?cedula=" + encodeURIComponent(cedula),
                    type: "DELETE",
                    dataType: "json",
                    success: function (response) {
                        if (response.message) {
                            actualizarTabla();
                        } else {
                            alert("Error al eliminar: " + (response.error || "Desconocido"));
                        }
                    }
                });
            }
        });
    }
}

function actualizarDatos() {
    var formData = {
        cedula: $('input[name="cedula"]').val(),
        nombre: $('input[name="nombre"]').val(),
        apellido: $('input[name="apellido"]').val(),
        direccion: $('input[name="direccion"]').val(),
        telefono: $('input[name="telefono"]').val()
    };

    $.ajax({
        url: "../Controller/ApiRest.php",
        type: "PUT",
        data: $.param(formData),
        contentType: "application/x-www-form-urlencoded",
        dataType: "json",
        success: function (response) {
            if (response.success) {
                actualizarTabla();
            } else {
                alert("Error al actualizar: " + response.error);
            }
        }
    });
}


$(document).ready(function () {
    $("#fm").submit(function (event) {
        event.preventDefault();
        guardarDatos();
    });
});

function actualizarTabla1() {
    alert("Operación exitosa, actualizando tabla...");

    $('#dlg').dialog('close');

    $.ajax({
        url: "../Controller/ApiRest.php",
        type: "GET",
        dataType: "json",
        success: function (data) {
            $('#dg').datagrid('loadData', data);
        }
    });
}


///////////boot

