$(document).ready(function () {
  cargarCursos();
  cargarEstudiantes();
  cargarMatriculados();
  cargarTablaEstudiantes();

  // Crear estudiante
  $('#form-estudiante').on('submit', function (e) {
    e.preventDefault();
    const estudiante = {
      nombre: $('input[name="nombre"]', this).val(),
      cedula: $('input[name="cedula"]', this).val(),
      correo: $('input[name="correo"]', this).val()
    };

    $.ajax({
      url: 'EstudianteController',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(estudiante),
      success: function () {
        alert('Estudiante insertado');
        $('#form-estudiante')[0].reset();
        cargarEstudiantes();
        cargarTablaEstudiantes();
      },
      error: () => alert('Error al insertar estudiante')
    });
  });

  // Crear curso
  $('#form-curso').on('submit', function (e) {
    e.preventDefault();
    const curso = {
      nombre: $('input[name="nombre"]').val(),
      descripcion: $('input[name="descripcion"]').val()
    };

    $.ajax({
      url: 'CursoController',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(curso),
      success: function () {
        alert('Curso creado');
        $('#form-curso')[0].reset();
        cargarCursos();
      },
      error: () => alert('Error al crear curso')
    });
  });

  // Matricular estudiante
  $('#form-matricula').on('submit', function (e) {
    e.preventDefault();
    const matricula = {
      idEstudiante: parseInt($('#select-estudiante').val()),
      idCurso: parseInt($('#select-curso').val())
    };

    $.ajax({
      url: 'MatriculaController',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(matricula),
      success: function (res) {
        if (res.success) {
          alert('Matriculado correctamente');
          cargarMatriculados();
        } else {
          alert('Ya está matriculado en ese curso');
        }
      },
      error: () => alert('Error al matricular')
    });
  });

  // Buscar por cédula
  $('#btnBuscarCedula').on('click', function () {
    const cedula = $('#buscarCedula').val().trim();
    if (!cedula) return alert('Ingresa una cédula');

    $.ajax({
      url: 'MatriculaController?cedula=' + cedula,
      type: 'GET',
      dataType: 'json',
      success: function (data) {
        const lista = $('#lista-matriculados');
        lista.empty();
        if (data.length === 0) {
          lista.append('<li class="list-group-item">No se encontraron matrículas</li>');
        } else {
          data.forEach(item => {
            lista.append(`<li class="list-group-item d-flex justify-content-between">
              <span>${item.estudiante} (${item.cedula}) → ${item.curso}</span>
              <div>
                <button class="btn btn-sm btn-primary me-1" onclick="editarMatriculaPrompt('${item.estudiante}', '${item.curso}')">Editar</button>
                <button class="btn btn-sm btn-danger" onclick="eliminarMatricula(${item.id})">Eliminar</button>
              </div>
            </li>`);
          });
        }
      },
      error: () => alert('Error en la búsqueda de matrículas')
    });
  });
});

// ========== FUNCIONES CRUD ==========

function cargarCursos() {
  $.ajax({
    url: 'CursoController',
    type: 'GET',
    dataType: 'json',
    success: function (data) {
      const tbody = $('#tabla-cursos tbody');
      const select = $('#select-curso');
      tbody.empty();
      select.empty();

      data.forEach(curso => {
        tbody.append(`<tr>
          <td>${curso.id}</td>
          <td>${curso.nombre}</td>
          <td>${curso.descripcion}</td>
          <td>
            <button class="btn btn-warning btn-sm" onclick='editarCurso(${JSON.stringify(curso)})'>Editar</button>
            <button class="btn btn-danger btn-sm" onclick='eliminarCurso(${curso.id})'>Eliminar</button>
          </td>
        </tr>`);
        select.append(`<option value="${curso.id}">${curso.nombre}</option>`);
      });
    }
  });
}

function cargarEstudiantes() {
  $.ajax({
    url: 'EstudianteController',
    type: 'GET',
    dataType: 'json',
    success: function (data) {
      const select = $('#select-estudiante');
      select.empty();
      data.forEach(e => {
        select.append(`<option value="${e.id}">${e.nombre} (${e.cedula})</option>`);
      });
    }
  });
}

function cargarTablaEstudiantes() {
  $.ajax({
    url: 'EstudianteController',
    type: 'GET',
    dataType: 'json',
    success: function (data) {
      const tbody = $('#tabla-estudiantes tbody');
      tbody.empty();
      data.forEach(e => {
        tbody.append(`<tr>
          <td>${e.id}</td>
          <td>${e.nombre}</td>
          <td>${e.cedula}</td>
          <td>${e.correo}</td>
          <td>
            <button class="btn btn-warning btn-sm" onclick='editarEstudiante(${JSON.stringify(e)})'>Editar</button>
            <button class="btn btn-danger btn-sm" onclick='eliminarEstudiante(${e.id})'>Eliminar</button>
          </td>
        </tr>`);
      });
    }
  });
}

function cargarMatriculados() {
  $.ajax({
    url: 'MatriculaController',
    type: 'GET',
    dataType: 'json',
    success: function (data) {
      const lista = $('#lista-matriculados');
      lista.empty();
      data.forEach(texto => {
        const [nombre, curso] = texto.split('→').map(e => e.trim());
        lista.append(`<li class="list-group-item d-flex justify-content-between align-items-center">
          <span>${cedula} ${nombre} → ${curso}</span>
          <div>
            <button class="btn btn-sm btn-primary me-1" onclick="editarMatriculaPrompt('${nombre}', '${curso}')">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="eliminarMatriculaPorNombreCurso('${nombre}', '${curso}')">Eliminar</button>
          </div>
        </li>`);
      });
    }
  });
}

// ========== FUNCIONES INDIVIDUALES ==========

function editarCurso(curso) {
  const nuevoNombre = prompt('Nuevo nombre:', curso.nombre);
  const nuevaDesc = prompt('Nueva descripción:', curso.descripcion);
  if (!nuevoNombre || !nuevaDesc) return;

  $.ajax({
    url: 'CursoController',
    type: 'PUT',
    contentType: 'application/json',
    data: JSON.stringify({ id: curso.id, nombre: nuevoNombre, descripcion: nuevaDesc }),
    success: function () {
      alert('Curso actualizado');
      cargarCursos();
    },
    error: () => alert('Error al actualizar curso')
  });
}

function eliminarCurso(id) {
  if (!confirm('¿Eliminar este curso?')) return;

  $.ajax({
    url: 'CursoController',
    type: 'DELETE',
    contentType: 'application/json',
    data: JSON.stringify({ id }),
    success: function () {
      alert('Curso eliminado');
      cargarCursos();
    },
    error: () => alert('Error al eliminar curso')
  });
}

function editarEstudiante(e) {
  const nuevoNombre = prompt('Nuevo nombre:', e.nombre);
  const nuevoCorreo = prompt('Nuevo correo:', e.correo);
  if (!nuevoNombre || !nuevoCorreo) return;

  $.ajax({
    url: 'EstudianteController',
    type: 'PUT',
    contentType: 'application/json',
    data: JSON.stringify({ id: e.id, nombre: nuevoNombre, cedula: e.cedula, correo: nuevoCorreo }),
    success: function () {
      alert('Estudiante actualizado');
      cargarEstudiantes();
      cargarTablaEstudiantes();
    },
    error: () => alert('Error al actualizar estudiante')
  });
}

function eliminarEstudiante(id) {
  if (!confirm('¿Eliminar este estudiante?')) return;

  $.ajax({
    url: 'EstudianteController',
    type: 'DELETE',
    contentType: 'application/json',
    data: JSON.stringify({ id }),
    success: function () {
      alert('Estudiante eliminado');
      cargarEstudiantes();
      cargarTablaEstudiantes();
    },
    error: () => alert('Error al eliminar estudiante')
  });
}

function eliminarMatricula(id) {
  if (!confirm('¿Eliminar esta matrícula?')) return;

  $.ajax({
    url: 'MatriculaController',
    type: 'DELETE',
    contentType: 'application/json',
    data: JSON.stringify({ id }),
    success: function () {
      alert('Matrícula eliminada');
      cargarMatriculados();
    },
    error: () => alert('Error al eliminar matrícula')
  });
}

function eliminarMatriculaPorNombreCurso(nombre, curso) {
  $.ajax({
    url: `MatriculaController?idByNombreCurso=true&estudiante=${encodeURIComponent(nombre)}&curso=${encodeURIComponent(curso)}`,
    type: 'GET',
    dataType: 'json',
    success: function (data) {
      if (data.id) eliminarMatricula(data.id);
      else alert('Matrícula no encontrada');
    },
    error: () => alert('Error buscando ID de matrícula')
  });
}

function editarMatriculaPrompt(nombre, cursoActual) {
  $.ajax({
    url: 'CursoController',
    type: 'GET',
    dataType: 'json',
    success: function (cursos) {
      const opciones = cursos.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
      const html = `
        <div class="modal fade" id="modalEditar" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Editar Matrícula</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <label>Nuevo curso para ${nombre}</label>
                <select class="form-select" id="nuevoCurso">
                  ${opciones}
                </select>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="confirmarEditar">Guardar cambios</button>
              </div>
            </div>
          </div>
        </div>`;

      $('body').append(html);
      const modal = new bootstrap.Modal(document.getElementById('modalEditar'));
      modal.show();

      $('#confirmarEditar').on('click', function () {
        const nuevoCurso = $('#nuevoCurso').val();
        $.ajax({
          url: `MatriculaController?idByNombreCurso=true&estudiante=${encodeURIComponent(nombre)}&curso=${encodeURIComponent(cursoActual)}`,
          type: 'GET',
          dataType: 'json',
          success: function (data) {
            if (data.id) {
              const nuevaMatricula = {
                id: data.id,
                idEstudiante: data.idEstudiante,
                idCurso: parseInt(nuevoCurso)
              };
              $.ajax({
                url: 'MatriculaController',
                type: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify(nuevaMatricula),
                success: function (res) {
                  if (res.success) {
                    alert('Matrícula actualizada');
                    cargarMatriculados();
                    modal.hide();
                    $('#modalEditar').remove();
                  } else {
                    alert('Error al actualizar matrícula');
                  }
                },
                error: () => alert('Error en la solicitud de actualización')
              });
            } else {
              alert('Matrícula no encontrada');
            }
          },
          error: () => alert('Error buscando ID de matrícula')
        });
      });
    },
    error: () => alert('Error al cargar cursos')
  });
}
