/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Models.Matricula;
import Utils.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Admini
 */
public class MatriculaDAO {
    public boolean registrar(Matricula m) {
        String checkSql = "SELECT COUNT(*) FROM matriculas WHERE id_estudiante=? AND id_curso=?";
        String insertSql = "INSERT INTO matriculas(id_estudiante, id_curso, fecha_matricula) VALUES (?, ?, NOW())";

        try (Connection con = Conexion.getConnection();
             PreparedStatement check = con.prepareStatement(checkSql)) {

            check.setInt(1, m.getIdEstudiante());
            check.setInt(2, m.getIdCurso());
            ResultSet rs = check.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) return false;

            try (PreparedStatement ps = con.prepareStatement(insertSql)) {
                ps.setInt(1, m.getIdEstudiante());
                ps.setInt(2, m.getIdCurso());
                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<String> listarMatriculados() {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT e.nombre AS estudiante, c.nombre AS curso FROM matriculas m JOIN estudiantes e ON m.id_estudiante = e.id JOIN cursos c ON m.id_curso = c.id";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String item = rs.getString("estudiante") + " → " + rs.getString("curso");
                lista.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean eliminar(int idMatricula) {
        String sql = "DELETE FROM matriculas WHERE id = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMatricula);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
public List<Map<String, Object>> listarPorCedula(String cedula) {
    List<Map<String, Object>> lista = new ArrayList<>();
    String sql = "SELECT m.id, e.nombre AS estudiante, e.cedula, c.nombre AS curso " +
                 "FROM matriculas m " +
                 "JOIN estudiantes e ON m.id_estudiante = e.id " +
                 "JOIN cursos c ON m.id_curso = c.id " +
                 "WHERE e.cedula = ?";

    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, cedula);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Map<String, Object> fila = new HashMap<>();
            fila.put("id", rs.getInt("id"));
            fila.put("estudiante", rs.getString("estudiante"));
            fila.put("cedula", rs.getString("cedula"));
            fila.put("curso", rs.getString("curso"));
            lista.add(fila);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return lista;
}

    public Matricula buscarPorNombreCurso(String nombreEstudiante, String nombreCurso) {
    String sql = "SELECT m.id, m.id_estudiante FROM matriculas m "
               + "JOIN estudiantes e ON e.id = m.id_estudiante "
               + "JOIN cursos c ON c.id = m.id_curso "
               + "WHERE e.nombre = ? AND c.nombre = ?";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, nombreEstudiante);
        ps.setString(2, nombreCurso);

        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            Matricula m = new Matricula();
            m.setId(rs.getInt("id"));
            m.setIdEstudiante(rs.getInt("id_estudiante"));
            return m;
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
    public boolean actualizar(Matricula m) {
    String sql = "UPDATE matriculas SET id_estudiante = ?, id_curso = ? WHERE id = ?";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, m.getIdEstudiante());
        ps.setInt(2, m.getIdCurso());
        ps.setInt(3, m.getId());
        return ps.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

    

}
