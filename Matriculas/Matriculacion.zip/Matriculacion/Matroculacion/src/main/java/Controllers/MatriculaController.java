/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;


import Models.Curso;
import Models.Estudiante;
import Models.Matricula;
import Services.MatriculaService;
import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Admini
 */
@WebServlet("/MatriculaController")
public class MatriculaController extends HttpServlet {
    private final MatriculaService service = new MatriculaService();
    private final Gson gson = new Gson();

@Override
protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
    res.setContentType("application/json");

    String cedula = req.getParameter("cedula");
    String byNombreCurso = req.getParameter("idByNombreCurso");

    if (cedula != null) {
        List<Map<String, Object>> lista = service.listarPorCedula(cedula);
        res.getWriter().write(gson.toJson(lista));
        return;
    }

    if ("true".equals(byNombreCurso)) {
        String estudiante = req.getParameter("estudiante");
        String curso = req.getParameter("curso");

        Matricula m = service.buscarPorNombreCurso(estudiante, curso);
        if (m != null) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", m.getId());
            data.put("idEstudiante", m.getIdEstudiante());
            res.getWriter().write(gson.toJson(data));
        } else {
            res.setStatus(HttpServletResponse.SC_NOT_FOUND);
            res.getWriter().write("{\"error\": \"Matrícula no encontrada\"}");
        }
        return;
    }

    List<String> lista = service.listarMatriculados();
    res.getWriter().write(gson.toJson(lista));
}


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Matricula m = gson.fromJson(req.getReader(), Matricula.class);
        boolean ok = service.registrar(m);
        res.setContentType("application/json");
        res.getWriter().write("{\"success\": " + ok + "}");
    }

    @Override
protected void doPut(HttpServletRequest req, HttpServletResponse res) throws IOException {
    Matricula m = gson.fromJson(req.getReader(), Matricula.class);
    boolean ok = service.actualizar(m);
    res.setContentType("application/json");
    res.getWriter().write("{\"success\": " + ok + "}");
}

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Matricula m = gson.fromJson(req.getReader(), Matricula.class);
        boolean ok = service.eliminar(m.getId());
        res.setContentType("application/json");
        res.getWriter().write("{\"success\": " + ok + "}");
    }
}
