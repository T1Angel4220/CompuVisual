/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Models.Curso;
import Services.CursoService;
import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author Admini
 */

@WebServlet("/CursoController")
public class CursoController extends HttpServlet {
    private final CursoService service = new CursoService();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setContentType("application/json");
        List<Curso> lista = service.listar();
        res.getWriter().write(gson.toJson(lista));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Curso curso = gson.fromJson(req.getReader(), Curso.class);
        boolean ok = service.registrar(curso);
        res.setContentType("application/json");
        res.getWriter().write("{\"success\": " + ok + "}");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Curso curso = gson.fromJson(req.getReader(), Curso.class);
        boolean ok = service.actualizar(curso);
        res.setContentType("application/json");
        res.getWriter().write("{\"success\": " + ok + "}");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Curso curso = gson.fromJson(req.getReader(), Curso.class);
        boolean ok = service.eliminar(curso.getId());
        res.setContentType("application/json");
        res.getWriter().write("{\"success\": " + ok + "}");
    }
}