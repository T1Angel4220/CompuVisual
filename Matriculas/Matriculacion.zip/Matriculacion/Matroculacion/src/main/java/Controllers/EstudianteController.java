/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Models.Estudiante;
import Services.EstudianteService;
import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author Admini
 */

@WebServlet("/EstudianteController")
public class EstudianteController extends HttpServlet {
    private EstudianteService service = new EstudianteService();
    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String cedula = request.getParameter("cedula");
        response.setContentType("application/json");
        if (cedula != null) {
            Estudiante est = service.buscarPorCedula(cedula);
            if (est != null) {
                response.getWriter().write(gson.toJson(est));
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("{}");
            }
        } else {
            List<Estudiante> lista = service.listar();
            response.getWriter().write(gson.toJson(lista));
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        BufferedReader reader = request.getReader();
        Estudiante est = gson.fromJson(reader, Estudiante.class);
        boolean ok = service.registrar(est);
        response.setContentType("application/json");
        response.getWriter().write("{\"success\": " + ok + "}");
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
        BufferedReader reader = request.getReader();
        Estudiante est = gson.fromJson(reader, Estudiante.class);
        boolean ok = service.actualizar(est);
        response.setContentType("application/json");
        response.getWriter().write("{\"success\": " + ok + "}");
    }

@Override
protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
    BufferedReader reader = request.getReader();
    Estudiante est = gson.fromJson(reader, Estudiante.class);
    boolean ok = service.eliminar(est.getId()); // CAMBIO A getId()
    response.setContentType("application/json");
    response.getWriter().write("{\"success\": " + ok + "}");
}

}


