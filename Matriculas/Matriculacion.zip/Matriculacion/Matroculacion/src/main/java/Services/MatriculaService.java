/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

import Dao.MatriculaDAO;
import Models.Matricula;
import java.util.List;
import java.util.Map;



/**
 *
 * @author Admini
 */

public class MatriculaService {
    private MatriculaDAO dao = new MatriculaDAO();

    public boolean registrar(Matricula m) {
        return dao.registrar(m);
    }

    public List<String> listarMatriculados() {
        return dao.listarMatriculados();
    }

    public boolean eliminar(int idMatricula) {
        return dao.eliminar(idMatricula);
    }
    public List<Map<String, Object>> buscarPorCedula(String cedula) {
    return dao.listarPorCedula(cedula);
}
    public Matricula buscarPorNombreCurso(String estudiante, String curso) {
    return dao.buscarPorNombreCurso(estudiante, curso);
}
    public List<Map<String, Object>> listarPorCedula(String cedula) {
    return dao.listarPorCedula(cedula);
}
    public boolean actualizar(Matricula m) {
    return dao.actualizar(m);
}




}
