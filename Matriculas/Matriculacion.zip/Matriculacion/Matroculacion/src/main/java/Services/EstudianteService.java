/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

import Dao.EstudianteDAO;
import Models.Estudiante;
import java.util.List;

/**
 *
 * @author Admini
 */

public class EstudianteService {
    private EstudianteDAO dao = new EstudianteDAO();

    public List<Estudiante> listar() {
        return dao.listar();
    }

    public boolean registrar(Estudiante e) {
        return dao.registrar(e);
    }

    public boolean actualizar(Estudiante e) {
        return dao.actualizar(e);
    }

public boolean eliminar(int id) {
    return dao.eliminar(id);
}


    public Estudiante buscarPorCedula(String cedula) {
        return dao.buscarPorCedula(cedula);
    }
    
}