/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

import Dao.CursoDAO;
import Models.Curso;
import java.util.List;

/**
 *
 * @author Admini
 */
public class CursoService {
    private CursoDAO dao = new CursoDAO();

    public List<Curso> listar() {
        return dao.listar();
    }

    public boolean registrar(Curso c) {
        return dao.registrar(c);
    }

    public boolean actualizar(Curso c) {
        return dao.actualizar(c);
    }

    public boolean eliminar(int id) {
        return dao.eliminar(id);
    }
}
