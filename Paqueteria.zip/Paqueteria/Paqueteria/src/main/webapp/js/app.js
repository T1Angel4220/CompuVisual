const API = 'EnvioController';

$(document).ready(() => {
  cargarPersonas();

  $('#formEnvio').submit(function (e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(this).entries());

    $.ajax({
      url: API,
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(data),
      success: (res) => {
        alert(res.success ? 'Paquete enviado' : 'Error al enviar');
        $('#formEnvio')[0].reset();
        cargarPersonas();
      },
      error: () => alert('Error al enviar paquete')
    });
  });

  $('#btnBuscarCedula').click(() => {
    const cedula = $('#buscarCedula').val().trim();
    if (!cedula) return alert('Ingresa una cédula');

    $.ajax({
      url: API + '?cedula=' + cedula,
      type: 'GET',
      dataType: 'json',
      success: (data) => {
        const tabla = $('#tablaResultados').empty();
        if (data.length === 0) {
          tabla.append('<tr><td colspan="4">Sin resultados</td></tr>');
        } else {
          data.forEach(e => {
            tabla.append(`<tr>
              <td>${e.producto}</td>
              <td>${e.origen}</td>
              <td>${e.destino}</td>
              <td>${e.estado}</td>
            </tr>`);
          });
        }
      },
      error: () => alert('Error en la búsqueda')
    });
  });
});

// Función para llenar select de personas (cedula + nombre)
function cargarPersonas() {
  $.ajax({
    url: 'PersonaController',
    type: 'GET',
    dataType: 'json',
    success: function (data) {
      const remitente = $('#cedulaRemitente').empty();
      const receptor = $('#cedulaReceptor').empty();
      remitente.append('<option value="">-- Seleccione Remitente --</option>');
      receptor.append('<option value="">-- Seleccione Receptor --</option>');
      data.forEach(p => {
        remitente.append(`<option value="${p.cedula}">${p.cedula} - ${p.nombre}</option>`);
        receptor.append(`<option value="${p.cedula}">${p.cedula} - ${p.nombre}</option>`);
      });
    }
  });
}
