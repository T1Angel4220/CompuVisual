/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Envio {
    private int id;
    private String cedulaRemitente;
    private String cedulaReceptor;
    private String producto;
    private String origen;
    private String destino;
    private String estado;

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCedulaRemitente() { return cedulaRemitente; }
    public void setCedulaRemitente(String cedulaRemitente) { this.cedulaRemitente = cedulaRemitente; }

    public String getCedulaReceptor() { return cedulaReceptor; }
    public void setCedulaReceptor(String cedulaReceptor) { this.cedulaReceptor = cedulaReceptor; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }

    public String getOrigen() { return origen; }
    public void setOrigen(String origen) { this.origen = origen; }

    public String getDestino() { return destino; }
    public void setDestino(String destino) { this.destino = destino; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
