/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Model.Persona;
import Util.Conexion;
import model.Envio;

import java.sql.*;
import java.util.*;

public class EnvioDAO {

    public boolean registrar(Envio envio, Persona remitente, Persona receptor) {
        try (Connection conn = Conexion.conectar()) {
            // Insertar personas si no existen
            insertarPersona(conn, remitente);
            insertarPersona(conn, receptor);

            // Insertar envío
            String sql = "INSERT INTO envios (cedula_remitente, cedula_receptor, producto, origen, destino, estado) VALUES (?, ?, ?, ?, ?, 'ENVIADO')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, envio.getCedulaRemitente());
            ps.setString(2, envio.getCedulaReceptor());
            ps.setString(3, envio.getProducto());
            ps.setString(4, envio.getOrigen());
            ps.setString(5, envio.getDestino());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void insertarPersona(Connection conn, Persona p) throws SQLException {
        String sql = "INSERT IGNORE INTO personas (cedula, nombre) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, p.getCedula());
        ps.setString(2, p.getNombre());
        ps.executeUpdate();
    }

    public List<Envio> buscarPorCedula(String cedula) {
        List<Envio> lista = new ArrayList<>();
        String sql = "SELECT * FROM envios WHERE cedula_remitente=? OR cedula_receptor=?";
        try (Connection conn = Conexion.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cedula);
            ps.setString(2, cedula);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Envio e = new Envio();
                e.setId(rs.getInt("id"));
                e.setCedulaRemitente(rs.getString("cedula_remitente"));
                e.setCedulaReceptor(rs.getString("cedula_receptor"));
                e.setProducto(rs.getString("producto"));
                e.setOrigen(rs.getString("origen"));
                e.setDestino(rs.getString("destino"));
                e.setEstado(rs.getString("estado"));
                lista.add(e);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
public List<Persona> obtenerPersonas() {
    List<Persona> lista = new ArrayList<>();
    String sql = "SELECT * FROM personas";
    try (Connection conn = Conexion.conectar();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            Persona p = new Persona();
            p.setCedula(rs.getString("cedula"));
            p.setNombre(rs.getString("nombre"));
            lista.add(p);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return lista;
}


}
