/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Model.Persona;
import com.google.gson.Gson;
import dao.EnvioDAO;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Envio;


import java.io.*;
import java.util.List;

public class ApiEnvios extends HttpServlet {
    private final Gson gson = new Gson();
    private final EnvioDAO dao = new EnvioDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        Envio envio = gson.fromJson(req.getReader(), Envio.class);
        Persona remitente = new Persona();
        Persona receptor = new Persona();

        remitente.setCedula(envio.getCedulaRemitente());
        remitente.setNombre(req.getParameter("nombreRemitente"));

        receptor.setCedula(envio.getCedulaReceptor());
        receptor.setNombre(req.getParameter("nombreReceptor"));

        boolean ok = dao.registrar(envio, remitente, receptor);
        res.setContentType("application/json");
        res.getWriter().write("{\"success\": " + ok + "}");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String cedula = req.getParameter("cedula");
        List<Envio> lista = dao.buscarPorCedula(cedula);
        res.setContentType("application/json");
        res.getWriter().write(gson.toJson(lista));
    }
}
